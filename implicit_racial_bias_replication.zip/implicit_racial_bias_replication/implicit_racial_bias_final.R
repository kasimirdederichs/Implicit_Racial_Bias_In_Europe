##################################################################################
#### IMPLICIT RACIAL BIAS IN EUROPE: CROSS-NATIONAL VARIATION AND TIME TRENDS ####
##################################################################################

#This script produces all figures and tables associated with the article:
#Dederichs, K. and PP. Verhaeghe 2024: Implicit Racial Bias in Europe: Cross-National Variation and Time Trends
#Sections of this script are based on the script provided by the authors of the Project Implicit. 
#For further reference see: Charlesworth et al. 2022: The project implicit international dataset: 
#Measuring implicit and explicit social group attitudes and stereotypes across 34 countries (2009–2019), 
#Behavior Research Methods, 55(3), 1413-1440, 10.3758/s13428-022-01851-2

# Load packages ----

if (!require(osfr)) {install.packages("osfr", dependencies = TRUE); require(osfr)}
if (!require(data.table)) {install.packages("data.table", dependencies = TRUE); require(data.table)}
if (!require(tidyr)) {install.packages("tidyr", dependencies = TRUE); require(tidyr)}
if (!require(dplyr)) {install.packages("dplyr", dependencies = TRUE); require(dplyr)}
if (!require(readr)) {install.packages("readr", dependencies = TRUE); require(readr)}
if (!require(lsr)) {install.packages("lsr", dependencies = TRUE); require(lsr)}
if (!require(weights)) {install.packages("weights", dependencies = TRUE); require(weights)}
if (!require(Hmisc)) {install.packages("Hmisc", dependencies = TRUE); require(Hmisc)}
if (!require(openxlsx)) {install.packages("openxlsx", dependencies = TRUE); require(openxlsx)}
if (!require(ggplot2)) {install.packages("ggplot2", dependencies = TRUE); require(ggplot2)}
if (!require(tidyverse)) {install.packages("tidyverse", dependencies = TRUE); require(tidyverse)}
if (!require(eurostat)) {install.packages("eurostat", dependencies = TRUE); require(eurostat)}
if (!require(leaflet)) {install.packages("leaflet", dependencies = TRUE); require(leaflet)}
if (!require(sf)) {install.packages("sf", dependencies = TRUE); require(sf)}
if (!require(scales)) {install.packages("scales", dependencies = TRUE); require(scales)}
if (!require(cowplot)) {install.packages("cowplot", dependencies = TRUE); require(cowplot)}
if (!require(ggthemes)) {install.packages("ggthemes", dependencies = TRUE); require(ggthemes)}
if (!require(giscoR)) {install.packages("giscoR", dependencies = TRUE); require(giscoR)}
if (!require(patchwork)) {install.packages("patchwork", dependencies = TRUE); require(patchwork)}
if (!require(anesrake)) {install.packages("anesrake", dependencies = TRUE); require(anesrake)}
if (!require(sf)) {install.packages("sf", dependencies = TRUE); require(sf)}
if (!require(rnaturalearth)) {install.packages("rnaturalearth", dependencies = TRUE); require(rnaturalearth)}
if (!require(magick)) {install.packages("magick", dependencies = TRUE); require(magick)}
if (!require(grid)) {install.packages("grid", dependencies = TRUE); require(grid)}
devtools::install_github("ropensci/rnaturalearthhires")


# Specify main project folder and create folders manually ####
mainprojectfolder <- "path/implicit_bias_across_europe/"
#Please create the following subfolders in this main project folder:
##02_data
###country_level_covariates
###orig_data_project_implicit
###shapefiles
###targets_for_weighting_data
###weighted_data_project_implicit
##04_outputs

# Download data from OSF ----
setwd(paste0(mainprojectfolder, "02_data/weighted_data_project_implicit/"))
#specify all countries we want to download the data for:
all_countries_of_interest_download <- c('Germany', 'Hungary', 'Poland', 'Norway', 'Portugal', 'Denmark', 
                               'Austria', 'Italy', 'Spain', 'Sweden', 'Belgium', 'France', 'Netherlands',
                               'United Kingdom', 'Ireland', 'Romania', 
                               'Switzerland (German)', 'Switzerland (French)', 'Czech Republic')

#download the data for all countries:
for(country_of_interest in all_countries_of_interest_download) {
  # Project's top node
  topnode <- osf_retrieve_node("https://osf.io/26pkd/") # get list of nodes within the full project
  tasknodes <- osf_ls_nodes(topnode) # The node info for all tasks
  
  # Pull out Race task node
  racetaskid <- tasknodes[tasknodes$name == "Race",]
  racetask <- osf_ls_nodes(racetaskid, n_max = Inf, verbose = TRUE) 
  
  # Pull out country within Race
  table(racetask$name)
  race <- osf_retrieve_node(racetask$id[racetask$name == country_of_interest])
  race_dat <- osf_retrieve_node(osf_ls_nodes(race)$id[which(osf_ls_nodes(race)$name == "Datasets and codebooks")]) 
  race_files <- osf_ls_files(race_dat) 
  
  osf_download(race_files[race_files$name == "data.zip",], # download the wide data.zip file from the component to the open working directory
               path = paste0(mainprojectfolder, "02_data/orig_data_project_implicit/orig_data_", country_of_interest),
               conflicts = "overwrite",
               verbose = TRUE, # will report the OSF API interactions
               progress = TRUE) # will report the download progress
}

#Switzerland is a special case: They have two separate surveys. We thus pool the data from both surveys (one in German and one in French):
race_in_SwitzerlandGer <- read.csv(unz(paste0("orig_data_project_implicit/orig_data_Switzerland (German)/data.zip"),"race_iat_wide_2009-2019.csv"), header = TRUE, sep = ",") # unzip and read in the data
race_in_SwitzerlandFre <- read.csv(unz(paste0("orig_data_project_implicit/orig_data_Switzerland (French)/data.zip"),"race_iat_wide_2009-2019.csv"), header = TRUE, sep = ",") # unzip and read in the data

race_in_SwitzerlandGer <- race_in_SwitzerlandGer %>% 
    mutate(edu = case_when(edu %in% c('SEK') ~ 'isced0_2',
                           edu %in% c('GYM', 'BER', 'LEH', 'EFZ', 'EBA', 'AND', 'MIT', 'FMA', 'ANL') ~ 'isced3_4',
                           edu %in% c('HFD', 'EDP', 'EFA', 'FHD', 'FHB', 'FHM', 'FHW', 'ULD', 'UBA', 'UMA', 'AUF', 'UWB', 'DOK') ~ 'isced5_8'))
  #no race question available in this questionnaire.

race_in_SwitzerlandFre <- race_in_SwitzerlandFre %>% 
    mutate(edu = case_when(edu %in% c('1') ~ 'isced0_2',
                           edu %in% c('2', '3', '4', '5') ~ 'isced3_4',
                           edu %in% c('6', '7', '8') ~ 'isced5_8')) %>%
    filter(raceomb=='BLA')

race_in_Switzerland <- rbind(race_in_SwitzerlandGer, race_in_SwitzerlandFre)
write.csv(race_in_Switzerland, paste0(mainprojectfolder, "02_data/orig_data_project_implicit/orig_data_Switzerland/race_iat_wide_2009-2019.csv"))

#create a new version of the country vector, this time only one entry for Switzerland.
all_countries_of_interest <- c('Germany', 'Hungary', 'Poland', 'Norway', 'Portugal', 'Denmark', 
                               'Austria', 'Italy', 'Spain', 'Sweden', 'Belgium', 'France', 'Netherlands', 'Romania',
                               'United Kingdom', 'Ireland', 'Switzerland', 'Czech Republic')

# Harmonize data across countries (restrict to relevant variables, comparable education variable) ----
for(country_of_interest in all_countries_of_interest) {
#For Switzerland, we've already got a csv file, for all other countries, we need to unzip first. 
if(country_of_interest=='Switzerland'){
  race_in <- read.csv(paste0("orig_data_project_implicit/orig_data_", country_of_interest, "/race_iat_wide_2009-2019.csv"), header = TRUE, sep = ",") # read in the data (already unzipped for Switzerland)
}else{
  race_in <- read.csv(unz(paste0("orig_data_project_implicit/orig_data_", country_of_interest, "/data.zip"), "race_iat_wide_2009-2019.csv"), header = TRUE, sep = ",") # unzip and read in the data
}

# Filter to fewer columns 
colnames(race_in) # see all available data
race_in <- race_in[c("sessionId", "att", "diff_thermo", "D2.D.White_Good_all", 
                         "year", "month", "date", "num",
                         "sex", "age", "countryres", "countrycit", 
                         "raceomb", "ethnicityomb", "politicalid", "religion", "edu")]
colnames(race_in)[4] <- c("dscore")

# Filter to only complete IAT scores and complete socio-demographic information for weighting:
nrow(race_in)
race_in <- race_in[is.na(race_in$dscore)==FALSE,]
nrow(race_in)
race_in <- race_in %>% filter(!is.na(sex) & !is.na(age) & !is.na(edu) & !is.na(politicalid))

# Revise attitude scale
race_in$att <- race_in$att - 4

#country-specific bit: recode education variable and keep only ethnic majority members
if(country_of_interest=='Germany'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('GRU', 'HAU', 'REA') ~ 'isced0_2',
                                                edu %in% c('ABI', 'UNU') ~ 'isced3_4',
                                                edu %in% c('MAG', 'BAC', 'MSD', 'DIP', 'PHD', 'OTH') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='EUR')
}
if(country_of_interest=='Hungary'){
  race_in <- race_in %>% mutate(edu = case_when(edu %in% c('ALT', 'SZM') ~ 'isced0_2',
                                                edu %in% c('SZA', 'ERE') ~ 'isced3_4',
                                                edu %in% c('FOI', 'EGY', 'MBA', 'PHD', 'MFO') ~ 'isced5_8')) %>%
    filter(raceomb=='EUR' | ethnicityomb=='MAG')
}
if(country_of_interest=='Poland'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('SZP') ~ 'isced0_2',
                           edu %in% c('TEC', 'GIM') ~ 'isced3_4',
                           edu %in% c('LIM', 'LIT', 'MGR', 'DOK') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='POL')
}
if(country_of_interest=='Norway'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('FOL', 'UNG') ~ 'isced0_2',
                           edu %in% c('VGP', 'VGF') ~ 'isced3_4',
                           edu %in% c('HUP', 'LGF', 'HGP', 'MAF', 'PHD', 'AHG') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='NOR' | raceomb=='NOR')
}
if(country_of_interest=='Portugal'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('ESC', 'JSC', 'SHS') ~ 'isced0_2',
                           edu %in% c('HSG') ~ 'isced3_4',
                           edu %in% c('SCL', 'BSD', 'SGS', 'MBA', 'MDG', 'PHD', 'OAD') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='EUM' | raceomb=='BRA')
}
if(country_of_interest=='Denmark'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('ESC') ~ 'isced0_2',
                           edu %in% c('HSG') ~ 'isced3_4',
                           edu %in% c('BSD', 'MSD', 'MBA', 'HUM', 'JDG', 'SOC', 'MDG', 'PHD', 'OAD') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='DAN' | raceomb=='HVI')
}
if(country_of_interest=='Czech Republic'){
  race_in <- race_in %>%
    mutate(edu = case_when(edu %in% c('NSC', 'IES', 'ESC', 'ANE', 'SNE') ~ 'isced0_2',
                           edu %in% c('CSE', 'AEX', 'GSC', 'SPL') ~ 'isced3_4',
                           edu %in% c('HSP', 'SCL', 'BSD', 'COL', 'SGR', 'GRD', 'SCI') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='CZE' | raceomb=='CZL')
}
if(country_of_interest=='Austria'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('VOL', 'HAU') ~ 'isced0_2',
                           edu %in% c('BHS', 'MAT', 'UNU') ~ 'isced3_4',
                           edu %in% c('MAG', 'BAC', 'MSD', 'DIP', 'PHD', 'OTH') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='EUR')
}
if(country_of_interest=='Italy'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('1', '2') ~ 'isced0_2',
                           edu %in% c('3') ~ 'isced3_4',
                           edu %in% c('4', '5', '6', '7', '8', '9') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='MED' | raceomb=='SAE')
}
if(country_of_interest=='Spain'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('ESC', 'JSC', 'SHS') ~ 'isced0_2',
                           edu %in% c('SHP', 'SHPI', 'HSG', 'ASD') ~ 'isced3_4',
                           edu %in% c('SCL', 'MSD', 'MBA', 'JDG', 'PTG') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='EUR' | raceomb=='WHI')
}
if(country_of_interest=='Sweden'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('JSC') ~ 'isced0_2',
                           edu %in% c('SHS', 'HSG', 'SCL') ~ 'isced3_4',
                           edu %in% c('ASD', 'BSK', 'BSM', 'MBA', 'JDG', 'MDG', 'PSY', 'AYE', 'PHD', 'OAD') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='SVE' | raceomb=='EUR')
}
if(country_of_interest=='Belgium'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('ESC', 'JSC', 'SHS') ~ 'isced0_2',
                           edu %in% c('HSG', 'SCL') ~ 'isced3_4',
                           edu %in% c('ASD', 'BSD', 'MSD', 'MBA', 'PHD', 'OAD') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='VLA' | ethnicityomb=='WAA' | raceomb=='BLA')
}
if(country_of_interest=='France'){
  race_in <- race_in %>% 
    filter(edu!='7') %>%
    mutate(edu = case_when(edu %in% c('AUC', 'CER') ~ 'isced0_2',
                           edu %in% c('ELE', 'CAP', 'BEP', 'BAG', 'BAT') ~ 'isced3_4',
                           edu %in% c('UNP', 'UNS') ~ 'isced5_8')) %>%
    filter(raceomb=='BLA')
}
if(country_of_interest=='Netherlands'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('ESC', 'MAV') ~ 'isced0_2',
                           edu %in% c('HAV', 'VWO', 'MBO') ~ 'isced3_4',
                           edu %in% c('HBO', 'BAC', 'MAS') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='NLD' | raceomb=='NLD')
}
if(country_of_interest=='United Kingdom'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('NQU', 'ANY', 'OOO') ~ 'isced0_2',
                           edu %in% c('AAS', 'AAA') ~ 'isced3_4',
                           edu %in% c('FIR', 'HIG', 'FOU', 'INT', 'ADV', 'HNC', 'OQU') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='WBR' | raceomb=='WHI')
}
if(country_of_interest=='Ireland'){
  race_in <- race_in %>% 
    mutate(edu = case_when(edu %in% c('PSC', 'JCL') ~ 'isced0_2',
                           edu %in% c('LCL') ~ 'isced3_4',
                           edu %in% c('DIP', 'DEG', 'MAS', 'JDG', 'MDG', 'PHD', 'OAD') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='IRI' | raceomb=='IRI')
}
if(country_of_interest=='Romania'){
  race_in <- race_in %>%
    mutate(edu = case_when(edu %in% c('SPP', 'SPO', 'REA') ~ 'isced0_2',
                           edu %in% c('PRO', 'LIC') ~ 'isced3_4',
                           edu %in% c('UNI', 'MAS', 'DOC', 'PDO') ~ 'isced5_8')) %>%
    filter(ethnicityomb=='ROM' | raceomb=='WHI')
}



# Create Weights for each country ----
## Now set up target weights for weighting

## First doublecheck the factor levels
### sex
table(race_in$sex)
class(race_in$sex)
race_in$sex <- factor(race_in$sex, levels = c("f", "m"))

### age
table(race_in$age)
race_in$age <- factor(race_in$age, levels = c(7:89, "90+"),
                        labels = 7:90)
race_in$age <- as.numeric(as.character(race_in$age))
race_in$agecats <- cut(race_in$age, c(0,20,30,60,99))
table(race_in$agecats)
levels(race_in$agecats) <- c("age0019", "age2029", "age3059","age6099")

### education
table(race_in$edu)
race_in$edu <- factor(race_in$edu, levels = c('isced0_2', 'isced3_4', 'isced5_8'))

### political orientation:
race_in <- race_in %>%
  mutate(polilr = factor(case_when(politicalid==7 ~ 'lr0',
                            politicalid==6 ~ 'lr12',
                            politicalid==5 ~ 'lr34',
                            politicalid==4 ~ 'lr5',
                            politicalid==3 ~ 'lr67',
                            politicalid==2 ~ 'lr89',
                            politicalid==1 ~ 'lr10'), levels = c('lr0', 'lr12', 'lr34', 'lr5', 'lr67', 'lr89', 'lr10')))

### complete data on weighting targets
race_complete <- race_in[is.na(race_in$sex) == FALSE,]
race_complete <- race_complete[is.na(race_complete$agecats) == FALSE,]
race_complete <- race_in[is.na(race_in$edu) == FALSE,]
race_complete <- race_in[is.na(race_in$polilr) == FALSE,]

#### get the weights of the full population (2007 - 2020)
sex.weights_race <- as.data.frame(table(race_complete$sex)/sum(table(race_complete$sex)))$Freq
age.weights_race <- as.data.frame(table(race_complete$agecats)/sum(table(race_complete$agecats)))$Freq
edu.weights_race <- as.data.frame(table(race_complete$edu)/sum(table(race_complete$edu)))$Freq
pol.weights_race <- as.data.frame(table(race_complete$polilr)/sum(table(race_complete$polilr)))$Freq

### available distributions in data
available_race <- list(sex.weights_race, age.weights_race, edu.weights_race, pol.weights_race)  
names(available_race) <- c("Wsex", "Wage", "Wedu", "Wpol") 

# new matched variables in the data set
race_complete$Wsex <- as.numeric(race_complete$sex)
race_complete$Wage <- as.numeric(race_complete$agecats)
race_complete$Wedu <- as.numeric(race_complete$edu)
race_complete$Wpol <- as.numeric(race_complete$polilr)

### now write in the targets (get them from aggregated Eurostat data)
#sex
sex2019 <- read_csv2('targets_for_weighting_data/Eurostat/sexratios2019_eurostat.csv')
sex2019 <- sex2019 %>%
  mutate(perc_men = Males/Total, perc_women = Females/Total) %>%
  select(country, perc_men, perc_women) %>%
  filter(country == country_of_interest) %>% as.data.frame()
sex.targets <- as.vector(c(sex2019[1,3], sex2019[1,2])) #reversed: females first, males second to align with rest of script. 

#age
age2019 <- read_csv2('targets_for_weighting_data/Eurostat/agegroups2019_eurostat.csv')
age2019 <- age2019 %>% 
  mutate(age0019 = (`Less than 5 years` + `From 5 to 9 years` + `From 10 to 14 years` + `From 15 to 19 years`)/Total,
         age2029 = (`From 20 to 24 years` + `From 25 to 29 years`)/Total,
         age3059 = (`From 30 to 34 years` + `From 35 to 39 years` + `From 40 to 44 years` + `From 45 to 49 years` + `From 50 to 54 years` + `From 55 to 59 years`)/Total,
         age60oo = (`From 60 to 64 years` + `From 65 to 69 years` + `From 70 to 74 years` + `75 years or over`)/Total) %>%
  select(country, age0019, age2029, age3059, age60oo)  %>%
  filter(country == country_of_interest) %>% as.data.frame()

if(country_of_interest=='Romania'){
  age.targets <- as.vector(c(age2019[1,2], age2019[1,3], age2019[1,4])) #We don't have any older respondents in Romania, so we cannot re-weight the data properly here. 
  } else{
    age.targets <- as.vector(c(age2019[1,2], age2019[1,3], age2019[1,4], age2019[1,5]))
  } 

#education
educ2019 <- read_csv2('targets_for_weighting_data/Eurostat/educ2019_eurostat.csv')
educ2019 <- educ2019 %>% 
  mutate(isced0_2 = isced0_2/100, isced3_4=isced3_4/100, isced5_8=isced5_8/100) %>%
  filter(country == country_of_interest) %>% as.data.frame()
educ.targets <- as.vector(c(educ2019[1,2], educ2019[1,3], educ2019[1,4]))

#political left-right scale:
poli0919 <- read_csv2('targets_for_weighting_data/ESS/input_data_ess_left_right.csv')
poli0919 <- poli0919 %>%
  filter(Country == country_of_interest) %>% as.data.frame()
poli.targets <- as.vector(c(poli0919[1,2], poli0919[1,3], poli0919[1,4], 
                            poli0919[1,5], poli0919[1,6], poli0919[1,7], poli0919[1,8]))

### target distributions for the data
targets_race <- list(sex.targets, age.targets, educ.targets, poli.targets) #add educ.targets later on. 
names(targets_race) <- c("Wsex", "Wage", "Wedu", "Wpol") #add educ later on. 

## Weighting computation using anesrake (as suggested by Charlesworth et al. 2022)
weights_race <- anesrake(targets_race, race_complete, caseid = race_complete$sessionId,
                             verbose = TRUE, type = "nolim", convcrit=0.005, maxit = 1000)
#Note 1: The target distributions sometimes do not sum up to 100 due to rounding. anesrake adjusts them automatically.
#Note 2: The raking algorithm sometimes aceives only partial convergence. The average change in weights is in all cases very small. 

weights_race <- as.data.frame(weights_race[c("caseid", "weightvec")])
colnames(weights_race) <- c("sessionId", "weightvec")

race_complete <- merge(race_complete, weights_race, by = "sessionId")

#add variable to indicate country:
race_complete <- race_complete %>% mutate(country = country_of_interest)

#check if there are missing values on any of the relevant variables:
race_complete <- race_complete %>% 
  mutate(miss_var = if_else(is.na(sex) | is.na(age) | is.na(edu) | is.na(polilr) | is.na(dscore), 1, 0))

table(race_complete$miss_var) #only 1 observation. 
race_complete <- race_complete %>% filter(miss_var==0) %>% select(-miss_var)

## Now we have the final dataset with a weighting vector for sample demographics
write.csv(race_complete, file = paste0("weighted_data_project_implicit/race_weighted_", country_of_interest, ".csv"))
}

# Compile cross-country data frame ----
data_path <- paste0(mainprojectfolder, '02_data/weighted_data_project_implicit/')

files_df <- paste0(data_path, list.files(path = paste0(mainprojectfolder, '02_data/weighted_data_project_implicit/'), pattern = 'race_weighted_*')) %>% lapply(FUN=function(f) { 
  read.csv(f) })

data <- do.call(rbind, files_df)

data <- data %>% 
  mutate(miss_var = if_else(is.na(sex) | is.na(age) | is.na(edu) | is.na(polilr) | is.na(dscore), 1, 0))

table(data$miss_var) #only 39 observations. 
data <- data %>% filter(miss_var==0) %>% select(-miss_var)

write.csv(data, file = paste0(mainprojectfolder, '02_data/weighted_data_project_implicit/international_data_implicit_bias_weighted.csv'))
data <- read.csv(paste0(mainprojectfolder, '02_data/weighted_data_project_implicit/international_data_implicit_bias_weighted.csv'))

data <- data %>% 
  mutate(date_int = as.Date(date), 
         date_ym = substr(date, start = 1, stop = 7),
         date_month = paste0(year, '_', month))

# Create weights for overall time trend (to match population statistics of European countries) ----
#### get the weights of the full population (2007 - 2020)
country_N_in_data <- as.data.frame(table(data$country)/sum(table(data$country)))$Freq #vector of distribution of countries in alphabetical order

## Weighting computation
country_pop <- read.csv2(paste0(mainprojectfolder, '02_data/targets_for_weighting_data/Eurostat/sexratios2019_eurostat.csv'))

country_pop <- country_pop %>%
  mutate(Total = sub("[.]", "", Total),
         Total = sub("[.]", "", Total),
         Total = as.numeric(Total))
total_pop <- sum(country_pop$Total)
country_weighting <- country_pop %>%
  arrange(country) %>%
  mutate(share_among_EU = Total / total_pop)

country_weighting <- cbind(country_weighting, country_N_in_data)
country_weighting <- country_weighting %>%
  mutate(country_weight=share_among_EU/country_N_in_data) %>%
  select(country, country_weight)

data <- merge(data, country_weighting, by = 'country')
data <- data %>% mutate(weightvec_country = weightvec * country_weight)

# Table 1 for supplement (descriptive overview of original data) ----
#define function that calculates weighted standard errors (obtained from https://nces.ed.gov/training/datauser/COMO_04/assets/COMO0411of13R.pdf, which cites Cochran’s 1977 definition of it.)
weighted.var.se <- function(x, w, na.rm=TRUE){
  if (na.rm) { w <- w[i <- !is.na(x)]; x <- x[i] }
  n = length(w)
  xWbar = weighted.mean(x,w,na.rm=na.rm)
  wbar = mean(w)
  out = n/((n-1)*sum(w)^2)*(sum((w*x-wbar*xWbar)^2)-2*xWbar*sum((w-wbar)*(w*x-wbar*xWbar))+xWbar^2*sum((w-wbar)^2))
  return(out)
}

data$all <- 'total'
tab1_country <- as.data.frame(round(prop.table(table(data$country)), digits = 3))

tab1_edu <- as.data.frame(round(prop.table(table(data$edu)), digits = 3))
tab1_edu <- cbind(tab1_edu, as.data.frame(round(table(data$edu), digits = 3)))
tab1_sex <- as.data.frame(round(prop.table(table(data$sex)), digits = 3))
tab1_sex <- cbind(tab1_sex, as.data.frame(round(table(data$sex), digits = 3)))
tab1_year <- as.data.frame(round(prop.table(table(data$year)), digits = 3))
tab1_year <- cbind(tab1_year, as.data.frame(round(table(data$year), digits = 3)))
tab1_polilr <- as.data.frame(round(prop.table(table(data$polilr)), digits = 3))
tab1_polilr <- cbind(tab1_polilr, as.data.frame(round(table(data$polilr), digits = 3)))
tab1_age <- as.data.frame(round(prop.table(table(data$agecats)), digits = 3))
tab1_age <- cbind(tab1_age, as.data.frame(round(table(data$agecats), digits = 3)))
tab1_total <- as.data.frame(round(prop.table(table(data$all)), digits = 3))
tab1_total <- cbind(tab1_total, as.data.frame(round(table(data$all), digits = 3)))

tableS1 <- rbind(tab1_edu, tab1_sex, tab1_polilr, tab1_age, tab1_year, tab1_total)
tableS1 <- tableS1[, c(1,2,4)]

colnames(tableS1) <- c('Variable', 'Percentage', 'Frequency')
tableS1

write.xlsx(tableS1, paste0(mainprojectfolder, '02_data/outputs/tableS1.xlsx'))

tab1_dscore <- cbind(mean(data$dscore), sd(data$dscore))

tab1_age <- cbind(mean(data$age), sd(data$age))


# Table 2 for supplement (country-level D-scores and mean differences) ----
#summary overview:
dfweights <- data %>%   
  group_by(country) %>%   
  summarise(N = n(),
            #dscore_mean = mean(dscore),
            dscore_wmean = weighted.mean(dscore, weightvec),
            dscore_wsd = sqrt(wtd.var(dscore, weightvec)),
            dscore_wse = weighted.var.se(dscore, weightvec)) %>%
  mutate(dscore_wlci = dscore_wmean-1.96*dscore_wse,
         dscore_wuci = dscore_wmean+1.96*dscore_wse)

write.csv2(dfweights, paste0(mainprojectfolder, '02_data/country_level_covariates/dfweights.csv'))

#Matrix of pairwise country comparisons:
means <- dfweights$dscore_wmean
standard_errors <- dfweights$dscore_wse
n_means <- length(means)

meandiff_matrix <- matrix(NA, nrow = n_means, ncol = n_means) # Initialize matrix to store mean differences
p_value_matrix <- matrix(NA, nrow = n_means, ncol = n_means) # Initialize matrix to store p-values

# Pairwise comparisons
for (i in 1:(n_means-1)) {
  for (j in (i+1):n_means) {
    mean_diff <- means[i] - means[j]
    se_diff <- sqrt(standard_errors[i]^2 + standard_errors[j]^2)
    
    t_stat <- mean_diff / se_diff
    df <- Inf  # Assume large sample size for simplicity, or you can use the Welch-Satterthwaite equation to approximate the degrees of freedom
    p_value <- 2 * pt(-abs(t_stat), df)  # Two-tailed test
    
    # Fill in matrices
    meandiff_matrix[i, j] <- mean_diff
    meandiff_matrix[j, i] <- mean_diff  # Symmetric matrix
    
    p_value_matrix[i, j] <- p_value
    p_value_matrix[j, i] <- p_value  # Symmetric matrix
  }
}

meandiff_matrix <- as.data.frame(round(meandiff_matrix, digits = 3))
round(p_value_matrix, digits = 3) #all country differences are statistically sign at p<0.001 except Austria-France.--> no need to show all individual p-values.
dfweights_for_suppl <- dfweights %>%
  mutate(dscore_wmean = round(dscore_wmean, digits = 3), dscore_wsd = round(dscore_wsd, digits = 3)) %>%
  select(country, N, dscore_wmean, dscore_wsd)
tableS2 <- cbind(dfweights_for_suppl, meandiff_matrix)
colnames(tableS2) <- c("Country", "N", "D Score, Mean", "D Score, SD", "Diff_AT", "Diff_BE", "Diff_CZ", "Diff_DK", "Diff_FR", "DIFF_DE", "DIFF_HU", "DIFF_IE", "DIFF_IT", 
                       "DIFF_NL", "DIFF_NO", "DIFF_PL", "DIFF_PT", "DIFF_RO", "DIFF_ES", "DIFF_SE", "DIFF_CH", "DIFF_UK")

write.xlsx(tableS2, paste0(mainprojectfolder, '04_outputs/tableS2.xlsx'))


# Table 3 for supplement (correlation matrix of country-level variables) ----

cl_estimates <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/dfweights.csv'))
cl_gdp <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/GDP per capita.csv'))
cl_gini <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/Gini index per country.csv')) 
cl_heduc <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/Higher educated per country.csv'))
cl_fborn <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/foreignborn.csv'))
cl_mage <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/medianage.csv'))
cl_poverty <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/poverty per country.csv'))

cl_estimates <- merge(cl_estimates, cl_gdp, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_gini, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_heduc, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_fborn, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_mage, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_poverty, by = 'country', all.x = T, all.y = F)

cl_estimates <- cl_estimates %>% 
  mutate(percfborn = as.numeric(nbornforeigncntry)/as.numeric(Ntotalpopulation),
         gdppercapita = as.numeric(gdppercapita),
         medianage = as.numeric(medianage),
         povertyrate = as.numeric(povertyrate))


# Define a function to perform cor.test and extract relevant results
perform_cor_test <- function(x, y) {
  test_result <- cor.test(x, y, conf.level = 0.90)
  data.frame(
    correlation = test_result$estimate,
    lower_ci = test_result$conf.int[1],
    upper_ci = test_result$conf.int[2]
  )
}

# List of variable pairs to test
variable_pairs <- list(
  c("dscore_wmean", "gdppercapita"),
  c("dscore_wmean", "gini"),
  c("dscore_wmean", "percfborn"),
  c("dscore_wmean", "perchighedu"),
  c("dscore_wmean", "medianage"),
  c("dscore_wmean", "povertyrate")
)

# Apply the perform_cor_test function to each pair and combine results into a data frame
tableS3 <- do.call(rbind, lapply(variable_pairs, function(pair) {
  result <- perform_cor_test(cl_estimates[[pair[1]]], cl_estimates[[pair[2]]])
  result$pair <- paste(pair, collapse = " & ")
  return(result)
}))

tableS3 <- tableS3 %>%
  mutate(correlation = round(correlation, digits = 3),
         lower_ci = round(lower_ci, digits = 3),
         upper_ci = round(upper_ci, digits = 3)) %>%
  select(c("pair", "correlation", "lower_ci", "upper_ci"))
write.xlsx(tableS3, paste0(mainprojectfolder, '04_outputs/tableS3.xlsx'))

# Main Figure, Panel A (Map) ----
dfweights <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/dfweights.csv'))

#use the naturalearth package to obtain a shape file of Europe:
tdf <- ne_countries(continent = "Europe", scale = 10)

# Define the CRS centered on Europe using Lambert Azimuthal Equal-Area projection
# We use EPSG:3035 which is an appropriate CRS for Europe.
crs_europe <- "EPSG:3035"

# Transform the world map to the new CRS
tdf <- st_transform(tdf, crs = crs_europe)

tdf <- st_as_sf(tdf)

tdf <- tdf %>% filter(formal_en %in% c("Bosnia and Herzegovina", "Czech Republic", "Federal Republic of Germany", "French Republic", "Grand Duchy of Luxembourg",
                                       "Hellenic Republic", "Ireland", "Italian Republic", "Kingdom of Belgium", "Kingdom of Denmark", "Kingdom of Norway",
                                       "Kingdom of Spain", "Kingdom of Sweden", "Kingdom of the Netherlands", "Montenegro", "Principality of Andorra", "Portuguese Republic",
                                       "Republic of Albania", "Republic of Austria", "Republic of Belarus", "Republic of Bulgaria", "Republic of Croatia",
                                       "Republic of Finland", "Republic of Estonia", "Republic of Hungary", "Republic of Kosovo",
                                       "Republic of Latvia", "Republic of Lithuania", "Republic of North Macedonia", "Republic of Moldova", "Republic of Poland", "Republic of Serbia",
                                       "Republic of Slovenia", "Republic of Turkey", "Romania", "Slovak Republic", "Swiss Confederation", "Ukraine",
                                       "United Kingdom of Great Britain and Northern Ireland")) %>%
  mutate(country = case_when(formal_en=="Czech Republic" ~ "Czech Republic", formal_en=="Federal Republic of Germany" ~ "Germany",
                               formal_en=="French Republic" ~"France", formal_en=="Ireland" ~ "Ireland",
                               formal_en=="Italian Republic" ~ "Italy", formal_en=="Kingdom of Belgium" ~ "Belgium",
                               formal_en=="Kingdom of Denmark" ~ "Denmark", formal_en=="Kingdom of Norway" ~ "Norway",
                               formal_en=="Kingdom of Spain" ~ "Spain", formal_en=="Kingdom of Sweden" ~ "Sweden",
                               formal_en=="Kingdom of the Netherlands" ~ "Netherlands", formal_en=="Portuguese Republic" ~ "Portugal",
                               formal_en=="Republic of Austria" ~"Austria", formal_en=="Republic of Hungary" ~ "Hungary",
                               formal_en=="Republic of Poland" ~ "Poland", formal_en=="Romania" ~ "Romania", 
                               formal_en=="Swiss Confederation" ~ "Switzerland", formal_en=="United Kingdom of Great Britain and Northern Ireland" ~ "United Kingdom",
                               formal_en=="Bosnia and Herzegovina" ~ "BH", formal_en=="Grand Duchy of Luxembourg" ~ "LU",
                               formal_en=="Hellenic Republic" ~ "GR", formal_en=="Montenegro" ~ "MO", 
                               formal_en=="Republic of Albania" ~ "AL", formal_en=="Republic of Belarus" ~ "BL",
                               formal_en=="Republic of Bulgaria" ~ "BG", formal_en=="Republic of Croatia" ~ "HR",
                               formal_en=="Republic of Finland" ~ "FI", formal_en=="Republic of Estonia" ~ "EE", 
                               formal_en=="Republic of Kosovo" ~ "KO",
                               formal_en=="Republic of Latvia" ~ "LV", formal_en=="Republic of Lithuania" ~ "LT", 
                               formal_en=="Republic of North Macedonia" ~ "NM", formal_en=="Republic of Moldova" ~ "MV", 
                               formal_en=="Republic of Serbia" ~ "SR", formal_en=="Republic of Slovenia" ~ "SL", 
                               formal_en=="Republic of Turkey" ~ "TR", formal_en=="Slovak Republic" ~ "SK", 
                               formal_en=="Ukraine" ~ "UR", formal_en=="Principality of Andorra" ~ "AN")) %>%
  select(c("country", "geometry"))

implicit_par_shp <- dfweights %>%
  select(country, dscore_wmean) %>%
  right_join(tdf, by = "country")  %>%
  as.data.frame()

#set boundaries for map:
disp_win_wgs84 <- st_sfc(st_point(c(-13, 30)), st_point(c(55, 70)),
                         crs = 4326)
disp_win_trans <- st_transform(disp_win_wgs84, crs = crs_europe)
disp_win_coord <- st_coordinates(disp_win_trans)

# Plot the map of European countries filled with a color corresponding to values
map_implicitbias <- implicit_par_shp %>% 
  ggplot(aes(fill = dscore_wmean, geometry = geometry)) +
  geom_sf(
    size = 0.1,
    color = "grey50"
  ) +
  scale_fill_distiller(
    palette = "YlGnBu",
    direction = 1, 
    limits = c(0.30, 0.56),
    name = "Implicit Racial Bias (Weighted average D-scores)",
    breaks = pretty_breaks(10),
    na.value = "grey80",
    guide = guide_colorbar(
      direction = "horizontal",    # Set the legend to horizontal
      title.position = "top",      # Place the title at the top of the legend
      title.hjust = 0.5,           # Center the title horizontally
      label.position = "bottom",   # Adjust labels to be below the bar
      barwidth = unit(7, "cm"),   # Width of the color bar
      barheight = unit(0.5, "cm"), # Height of the color bar
      ticks = TRUE, 
    )
  ) + 
  coord_sf(xlim = disp_win_coord[,'X'], ylim = disp_win_coord[,'Y'],
           datum = crs_europe, expand = FALSE) +
  labs() +
  theme_void() +
  theme(legend.position = c(0.015, 0.96),   # Position the legend at the top left
        legend.justification = c(0, 1), # Align the legend to the top left corner
        legend.title = element_text(size = 8),  # Smaller legend title
        legend.text = element_text(size = 6),   # Smaller legend values
        plot.title = element_text(size = 30, face = "bold"),
        plot.caption = element_text(size = 12, face = "italic"),
        panel.background = element_rect(fill = "white", color = NA),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin=unit(c(0,0,0,0),"cm")
  ) +
  annotate("text", x = 2089781, y = 5100077, label = "Less anti-Black bias", size = 2, color = "black", hjust = 0) +  
  annotate("text", x = 3873781, y = 5100077, label = "More anti-Black bias", size = 2, color = "black", hjust = 0)   

# Save the map as a PNG file
ggsave(paste0(mainprojectfolder, "04_outputs/fig_map.png"), map_implicitbias, width = 13.5, height = 14.5, units = "cm", dpi = 300)


# Main Figure, Panel B (Time trend) ----
countries_in_plot <- c('France', 'Germany', 'Italy', 'Spain', 'United Kingdom')
data_large_countries <- data %>%
  filter(country %in% countries_in_plot) 

fig_time_trend_pooled_country_weights <- ggplot() +
  geom_smooth(
    data = data,
    aes(x = date_int, y = dscore, weight = weightvec_country, linetype = "Europe"),
    method = 'loess',
    se = FALSE,
    linewidth = 1,
    color = 'black'
  ) +
  geom_smooth(
    data = data_large_countries,
    aes(x = date_int, y = dscore, color = country, weight = weightvec),
    method = 'loess',
    se = FALSE
  ) + 
  scale_color_manual(values = c(
    "France" = "#41b6c4",
    "Germany" = "#7fcdbb",
    "Italy" = "#0c2c84",
    "Spain" = "#1d91c0",
    "United Kingdom" = "#c7e9b4"
  )) +
  scale_linetype_manual(values = c("Europe" = "dotdash")) + 
  ylab('Implicit Racial Bias 
(Weighted average D-scores)') +
  xlab('') +
  scale_y_continuous(breaks = c(0.35, 0.4, 0.45, 0.5, 0.55, 0.6)) +
  scale_x_date(date_breaks = "years", date_labels = "%Y") +
  theme(
    panel.background = element_blank(),
    axis.line = element_line(colour = "black"),
    legend.position = 'bottom',  # Position the legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.title = element_blank(),  # Remove legend title
    legend.text = element_text(size = 8),  # Adjust legend text size
    legend.box = "horizontal",  # Stack legend items horizontally
    legend.spacing.y = unit(0, "cm"),  # Reduce vertical space in the legend
    legend.margin = margin(t = -25),  # Move legend closer to the plot
    axis.text.x = element_text(size = 6),  # Set x-axis values size to 6
    axis.text.y = element_text(size = 6),  # Set y-axis values size to 6
    axis.title.y = element_text(size = 8),  # Set the y-axis label size to 8
    legend.key = element_rect(fill = "white", color = NA),  # Change legend key background to white or transparent
    plot.margin = unit(c(0, 0.5, 0, 0.5), "cm")  # Adjust the margins to reduce space from the left and right border
  ) 

# Save the time line as a PNG file
ggsave(paste0(mainprojectfolder, "04_outputs/timeline.png"), fig_time_trend_pooled_country_weights, width = 13.5, height = 6, units = "cm", dpi = 300)


# Combine both panels to the final version of Figure 1 ----
# Load the two images
fig_map <- image_read(paste0(mainprojectfolder, "04_outputs/fig_map.png"))
timeline <- image_read(paste0(mainprojectfolder, "04_outputs/timeline.png"))

# Get the dimensions of the map
fig_map_info <- image_info(fig_map)
fig_map_width <- fig_map_info$width
fig_map_height <- fig_map_info$height

# Calculate the new heights to maintain the 66% and 34% ratio
total_height <- fig_map_height / 0.66  # Total height when fig_map is 66%
timeline_height <- total_height * 0.34 # Calculate the height of the timeline

# Resize the timeline to match the width of the map and the calculated height
timeline_scaled <- image_resize(timeline, paste0(fig_map_width, "x", timeline_height))

# Combine the images vertically
combined_image <- image_append(c(fig_map, timeline_scaled), stack = TRUE)

# Save the combined image
image_write(combined_image, path = paste0(mainprojectfolder, "04_outputs/combined_image.png"), format = "png")


#mean value for entire Europe between 2009 and 2019:
weighted.mean(data$dscore, data$weightvec_country)


# Country-level correlates ####

#import the country-level datasets:
cl_estimates <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/dfweights.csv'))
cl_gdp <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/GDP per capita.csv'))
cl_gini <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/Gini index per country.csv'))
cl_heduc <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/Higher educated per country.csv'))
cl_fborn <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/foreignborn.csv'))
cl_mage <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/medianage.csv'))
cl_poverty <- read.csv2(paste0(mainprojectfolder, '02_data/country_level_covariates/poverty per country.csv'))

#merge them into a single data frame. 
cl_estimates <- merge(cl_estimates, cl_gdp, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_gini, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_heduc, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_fborn, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_mage, by = 'country', all.x = T, all.y = F)
cl_estimates <- merge(cl_estimates, cl_poverty, by = 'country', all.x = T, all.y = F)

#calculate relevant co-variates:
cl_estimates <- cl_estimates %>% 
  mutate(percfborn = as.numeric(nbornforeigncntry)/as.numeric(Ntotalpopulation),
         gdppercapita = as.numeric(gdppercapita),
         medianage = as.numeric(medianage),
         povertyrate = as.numeric(povertyrate)) %>% 
  filter(country!='Serbia')

#define a function to perform cor.test and extract relevant results
perform_cor_test <- function(x, y) {
  test_result <- cor.test(x, y, conf.level = 0.90)
  data.frame(
    correlation = test_result$estimate,
    lower_ci = test_result$conf.int[1],
    upper_ci = test_result$conf.int[2]
  )
}

# List of variable pairs to test
variable_pairs <- list(
  c("dscore_wmean", "gdppercapita"),
  c("dscore_wmean", "gini"),
  c("dscore_wmean", "percfborn"),
  c("dscore_wmean", "perchighedu"),
  c("dscore_wmean", "medianage"),
  c("dscore_wmean", "povertyrate")
)

# Apply the perform_cor_test function to each pair and combine results into a data frame
results <- do.call(rbind, lapply(variable_pairs, function(pair) {
  result <- perform_cor_test(cl_estimates[[pair[1]]], cl_estimates[[pair[2]]])
  result$pair <- paste(pair, collapse = " & ")
  return(result)
}))

# Display the results
print(results)

ggplot(results, aes(x = pair, y = correlation)) +
  geom_point() +
  geom_errorbar(aes(ymin = lower_ci, ymax = upper_ci), width = 0.2) +
  theme_minimal() +
  coord_flip() +
  geom_hline(yintercept=0) +
  labs(title = "Correlation Coefficients with Confidence Intervals",
       x = "Variable Pairs",
       y = "Correlation Coefficient") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))



